/* 
 * Stackman library.
 * Implementation of the stack switching function, if it is done
 * in C (using in-line assembly)
 */
#define STACKMAN_BUILD_LIB
#include "stackman_impl.h"
